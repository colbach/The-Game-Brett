package thegamebrett.network;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import thegamebrett.assets.AssetsLoader;

/**
 *
 * @author christiancolbach
 */
public class HTMLHelper {

    public static String HTML = AssetsLoader.loadText_SuppressExceptions("web/index.html");
    /*static {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        URL url = classloader.getResource("thegamebrett/network/files/index.html");
        try {
            String content = new Scanner(new File(url.toURI())).useDelimiter("\\Z").next();
            HTML = content;
        } catch (URISyntaxException | FileNotFoundException ex) {
            Logger.getLogger(ControlDirector.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    
    public static String CSS = AssetsLoader.loadText_SuppressExceptions("web/style.css");
    /*static {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        URL url = classloader.getResource("thegamebrett/network/files/style.css");
        try {
            String content = new Scanner(new File(url.toURI())).useDelimiter("\\Z").next();
            CSS = content;
        } catch (URISyntaxException | FileNotFoundException ex) {
            Logger.getLogger(ControlDirector.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    
    public static String generateHTMLContent(String titel, Object[] choices, long messageID) {
        StringBuilder sb = new StringBuilder();
        sb.append("<h1>" + titel + "</h1>");
        for(int i=0; i<choices.length; i++) {
            if (choices[i] != null) {
                sb.append(generateHTMLButton(choices[i].toString(), messageID, i));
            }
        }
        return sb.toString();
    }
    
    public static String generateHTMLContent(String titel, String acknowledgment, long messageID) {
        StringBuilder sb = new StringBuilder();
        sb.append("<h1>" + titel + "</h1>");
        
        return "<h1>" + titel + "</h1><p>" + acknowledgment + "</p>";
    }
    
    private static String generateHTMLButton(String choice, long messageID, int anwerID) {
        return "<div align=\"center\"><button class=\"choices\" onclick=\"reply('" + messageID + "?" + anwerID+ "')\">" + choice + "</button></div>";
    }
}
