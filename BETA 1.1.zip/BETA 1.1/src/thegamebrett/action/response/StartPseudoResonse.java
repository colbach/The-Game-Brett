package thegamebrett.action.response;

import thegamebrett.action.ActionResponse;

/**
 * @author christiancolbach
 */
public class StartPseudoResonse implements ActionResponse {}
