package thegamebrett.action.request;

import thegamebrett.action.ActionRequest;

/**
 * @author Christian Colbach
 */
public interface SoundRequest extends ActionRequest {}
