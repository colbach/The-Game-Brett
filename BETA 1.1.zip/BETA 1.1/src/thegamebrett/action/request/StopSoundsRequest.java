package thegamebrett.action.request;

import thegamebrett.model.mediaeffect.SoundEffect;

/**
 * @author Christian Colbach
 */
public class StopSoundsRequest implements SoundRequest {}
