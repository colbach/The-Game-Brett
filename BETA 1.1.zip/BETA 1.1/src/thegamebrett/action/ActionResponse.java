package thegamebrett.action;

/**
 * @author Christian Colbach
 */
public interface ActionResponse {}
