package thegamebrett.action;

/**
 * @author Christian Colbach
 */
public interface ActionRequest {}