package thegamebrett.assets;

/**
 * @author Christian Colbach
 */
public class AssetNotExistsException extends Exception {}
