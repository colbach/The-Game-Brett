package tests;

import thegamebrett.network.httpserver.*;


/**
 * @author Christian Colbach
 */
public class HttpServerTest {

        //public static HttpServer manager = new HttpServer(8124, new RootDirectoryBasedDirector("/Users/christiancolbach/Desktop/root"));
	
	public static void main(String[] args) {
            
            Object o = null;
            synchronized(o) {
                System.out.println("sdfsdf");
            }

            //HttpServer server = new HttpServer(8031, new TestDirector());
            //HttpServer server = new HttpServer(8126, new TestDirector());
            //HttpServer server = new HttpServer(8112, new RootDirectoryBasedDirector("/Users/christiancolbach/Desktop/root"));
            
            //server.enableServer();
		
	}
	
}
