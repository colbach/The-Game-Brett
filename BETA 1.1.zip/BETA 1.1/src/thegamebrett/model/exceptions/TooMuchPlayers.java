package thegamebrett.model.exceptions;

/**
 * @author christiancolbach
 */
public class TooMuchPlayers extends Exception {

    @Override
    public String toString() {
        return "Too much players";
    }
    
}
